package ObjetosCompartidos;
/**
 *
 * @author Sergio
 */


import java.util.ArrayList;
import java.util.concurrent.Semaphore;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Despensa – recurso compartido entre Cocineros (productores) y Vendedores (consumidores).
 * Almacén con capacidad lógica ilimitada de unidades (cafés y rosquillas).
 * Sincronización: ReentrantLock + Condition (una por tipo).
 */
public class Despensa {

    // Semáforo con 20 permisos
    private Semaphore aforoVendedores = new Semaphore(50, true);
    private Semaphore aforoCocineros = new Semaphore(50, true);

    // Estanterías como listas de Strings
    private ArrayList<String> estanteriaCafes = new ArrayList<>();
    private ArrayList<String> estanteriaRosquillas = new ArrayList<>();

    // --- Café ---
    private Lock lockCafe = new ReentrantLock(true);          // justo
    private int contadorCafe = 0;
    private Condition cafeAvailable = lockCafe.newCondition();

    // --- Rosquilla ---
    private Lock lockRosquilla = new ReentrantLock(true);     // justo
    private int contadorRosquilla = 0;
    private Condition rosquillaAvailable = lockRosquilla.newCondition();




            /** Entra al mostrador (máx 5 clientes simultáneos). */
    public void pasarVendedoresDespensa(String id,int nc, int nr) throws InterruptedException {
        aforoVendedores.acquire();
        Logger.log(id + " entra en la despensa");
        System.out.println(id + " entra en la despensa");

        // Tomar cafés
        lockCafe.lock();
        try {
            while (estanteriaCafes.size() < nc) {
                cafeAvailable.await();
            }
            for (int i = 0; i < nc; i++) {
                String comanda = estanteriaCafes.remove(0);
                contadorCafe--;
                System.out.println("Vendedor retira: " + comanda);
            }
            Logger.log(id + " retira " + nc + " cafes");
        } finally {
            lockCafe.unlock();
        }

        // Tomar rosquillas
        lockRosquilla.lock();
        try {
            while (estanteriaRosquillas.size() < nr) {
                rosquillaAvailable.await();
            }
            for (int i = 0; i < nr; i++) {
                String comanda = estanteriaRosquillas.remove(0);
                contadorRosquilla--;
                System.out.println("Vendedor retira: " + comanda);
            }
            Logger.log(id + " retira " + nr + " rosquillas");
        } finally {
            lockRosquilla.unlock();
        }

        Thread.sleep((int)(1000 + (3000 - 1000) * Math.random())); // tiempo en despensa
        aforoVendedores.release();
    }
    
            /** Entra al mostrador (máx 5 clientes simultáneos). */
    public void pasarCocinerosDespensa(String id,int nc, int nr) throws InterruptedException {
        aforoCocineros.acquire();
        Logger.log(id + " entra en la despensa para depositar");
        System.out.println(id + " entra en la despensa para depositar");

        // Depositar cafés
        lockCafe.lock();
        try {
            for (int i = 0; i < nc; i++) {
                contadorCafe++;
                estanteriaCafes.add("Cafe-" + contadorCafe);
            }
            cafeAvailable.signalAll();
        } finally {
            lockCafe.unlock();
        }

        // Depositar rosquillas
        lockRosquilla.lock();
        try {
            for (int i = 0; i < nr; i++) {
                contadorRosquilla++;
                estanteriaRosquillas.add("Rosquilla-" + contadorRosquilla);
            }
            rosquillaAvailable.signalAll();
        } finally {
            lockRosquilla.unlock();
        }

        System.out.println("Cocinero" + id + " ha colocado los productos en la despensa");
        Logger.log("Cocinero" + id + " ha colocado los productos en la despensa");
        aforoCocineros.release();
    }
    
    /**
     * Obtiene el número de vendedores actualmente en la despensa.
     */
    public int getVendedoresEnDespensa() {
        return 50 - aforoVendedores.availablePermits();
    }
    
    /**
     * Obtiene el número de cocineros actualmente en la despensa.
     */
    public int getCocineroEnDespensa() {
        return 50 - aforoCocineros.availablePermits();
    }

    /** Lectura thread-safe del número de rosquillas almacenadas. */
    public int getRosquillas() {
        lockRosquilla.lock();
        try {
            return estanteriaRosquillas.size();
        } finally {
            lockRosquilla.unlock();
        }
    }
    /** Lectura thread-safe del número de cafés almacenados. */
    public int getCafes() {
        lockCafe.lock();
        try {
            return estanteriaCafes.size();
        } finally {
            lockCafe.unlock();
        }
    }
}
