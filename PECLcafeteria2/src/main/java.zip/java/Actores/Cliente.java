/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Actores;

/**
 *
 * @author Sergio
 */

import ObjetosCompartidos.EntradaCafeteria;
import ObjetosCompartidos.Caja;
import ObjetosCompartidos.Mostrador;
import ObjetosCompartidos.AreaConsumo;
import ObjetosCompartidos.Logger;
import ObjetosCompartidos.PauseController;

/**
 * Cliente (C-XXXX) – Parte 1
 * Ciclo:
 * Parque (5–10s) → Trayecto (3–9s) → Zona previa (cap 20, FIFO) →
 * Mostrador (cap 5, FIFO; espera stock) → Caja (cap 10; 2–5s) →
 * Área de consumición (cap 30; 10–15s) → Fin.
 */
public class Cliente implements Runnable {

    // --- Identidad ---
    private String id;

    // --- Recursos compartidos ---
    private EntradaCafeteria cafeteria; // control de aforos (previa y mostrador)
    private Mostrador mostrador; // stock (Lock + Condition)
    private Caja cajaPago; // control de aforo (caja)
    private AreaConsumo areaConsumo; // control de aforo (área de consumición)
    private PauseController pauseController; // control de pausa

    // Pedido
    private int cafesElegidos;
    private int rosquillasElegidas;

    public Cliente(String id, EntradaCafeteria cafeteria, Mostrador mostrador, Caja cajaPago, AreaConsumo areaConsumo,
            PauseController pauseController) {
        this.id = id;
        this.cafeteria = cafeteria;
        this.mostrador = mostrador;
        this.cajaPago = cajaPago;
        this.areaConsumo = areaConsumo;
        this.pauseController = pauseController;
    }

    @Override
    public void run() {
        try {
            // 1) Parque (5–10 s)
            Logger.log(id + " esta en el parque");
            System.out.println(id + " esta en el parque");
            Thread.sleep((int) (5000 + (10000 - 5000) * Math.random()));
            pauseController.checkPause();

            // 2) Trayecto a la cafetería (3–9 s)
            Logger.log(id + " se dirige a la cafeteria");
            System.out.println(id + " se dirige a la cafeteria");
            Thread.sleep((int) (3000 + (9000 - 3000) * Math.random()));
            pauseController.checkPause();

            // 3) Zona previa (máx 20, FIFO por fair=true)
            cafeteria.pasarZonaPrevia(id);
            Logger.log(id + " sale de la zona previa");
            System.out.println(id + " sale de la zona previa");

            // 4) Mostrador (máx 5, FIFO por fair=true) y selección de productos
            cafesElegidos = (int) (1 + Math.random() * 3); // 1–3 cafés
            rosquillasElegidas = (int) (Math.random() * 5); // 0–4 rosquillas
            // Esperar stock (Lock + Condition en Mostrador)
            if (cafesElegidos > 0 || rosquillasElegidas > 0)
                mostrador.pasarClienteMostrador(id, cafesElegidos, rosquillasElegidas);
            Logger.log(id + " ha seleccionado " + cafesElegidos + " cafes y " + rosquillasElegidas + " rosquillas");
            System.out.println(
                    id + " ha seleccionado " + cafesElegidos + " cafes y " + rosquillasElegidas + " rosquillas");
            Logger.log(id + " sale del mostrador");
            System.out.println(id + " sale del mostrador");

            // 5) Caja (aforo 10) + pagar (2–5 s)
            cajaPago.entrarCaja(id); // usa el semáforo interno
            Logger.log(id + " accede a la caja");
            System.out.println(id + " accede a la caja");
            cajaPago.pagar(id, cafesElegidos, rosquillasElegidas); // calcula total y simula tiempo de pago
            pauseController.checkPause();
            cajaPago.salirCaja(id);
            Logger.log(id + " paga y sale de la caja");
            System.out.println(id + " paga y sale de la caja");

            // 6) Área de consumición (aforo 30; 10–15 s)
            areaConsumo.pasarAreaConsumo(id);
            Logger.log(id + " termina y se va");
            System.out.println(id + " termina y se va");
        } catch (InterruptedException e) {
            e.printStackTrace();
            Logger.log(id + " ha sido interrumpido");
            System.out.println(id + " ha sido interrumpido.");
        }

    }
}